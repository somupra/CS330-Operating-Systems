int getWalkOver(int numPlayers)
{
	return 2; // The second active player gets walkthrough
}